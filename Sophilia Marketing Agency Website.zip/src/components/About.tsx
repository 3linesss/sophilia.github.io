import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { CheckCircle2 } from "lucide-react";

const values = [
  "Creative Excellence",
  "Data-Driven Results",
  "Client-Centric Approach",
  "Innovation & Trends",
];

export function About() {
  return (
    <section id="about" className="py-20 px-6 bg-gray-50">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-4xl lg:text-5xl mb-6 text-gray-900">
              Creativity Meets Strategy
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              At Sophilia, we believe that great advertising is born from the
              perfect blend of artistic vision and strategic thinking. Since our
              founding, we've helped brands tell their stories in ways that
              resonate, inspire, and drive action.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              Our team of creative strategists, designers, and marketing experts
              work collaboratively to deliver campaigns that don't just look
              good—they perform exceptionally.
            </p>

            <div className="space-y-4 mb-8">
              {values.map((value, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="text-[#0177cc]" size={24} />
                  <span className="text-lg text-gray-700">{value}</span>
                </div>
              ))}
            </div>

            <Button size="lg" className="bg-[#0177cc] hover:bg-[#015a99]">
              Learn More About Us
            </Button>
          </div>

          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758518729685-f88df7890776?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjBtZWV0aW5nfGVufDF8fHx8MTc2MDUyODcyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Modern office meeting"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -top-6 -right-6 bg-[#0177cc] text-white p-8 rounded-xl shadow-xl">
                <div className="text-4xl mb-2">10+</div>
                <div className="text-sm">Years of Excellence</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
