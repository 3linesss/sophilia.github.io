import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import {
  Megaphone,
  Palette,
  TrendingUp,
  Video,
  Globe,
  Target,
} from "lucide-react";

const services = [
  {
    icon: Megaphone,
    title: "Brand Strategy",
    description:
      "Develop a compelling brand identity that resonates with your target audience and stands out in the market.",
  },
  {
    icon: Palette,
    title: "Creative Design",
    description:
      "Eye-catching visuals and innovative designs that tell your brand story and captivate your audience.",
  },
  {
    icon: Video,
    title: "Video Production",
    description:
      "Professional video content that engages viewers and delivers your message with impact and emotion.",
  },
  {
    icon: TrendingUp,
    title: "Digital Marketing",
    description:
      "Data-driven campaigns across social media, search, and display to maximize your ROI and reach.",
  },
  {
    icon: Globe,
    title: "Web & Social",
    description:
      "Stunning websites and social media presence that convert visitors into loyal customers.",
  },
  {
    icon: Target,
    title: "Media Planning",
    description:
      "Strategic media placement to ensure your message reaches the right people at the right time.",
  },
];

export function Services() {
  return (
    <section id="services" className="py-20 px-6 bg-gray-50">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl mb-4 text-gray-900">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive advertising solutions tailored to elevate your brand
            and achieve your business goals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="border-none shadow-lg hover:shadow-xl transition-shadow bg-white"
            >
              <CardHeader>
                <div className="w-14 h-14 bg-[#cceeff] rounded-lg flex items-center justify-center mb-4">
                  <service.icon className="text-[#0177cc]" size={28} />
                </div>
                <CardTitle>{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
