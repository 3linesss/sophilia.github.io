import { Button } from "./ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="pt-32 pb-20 px-6">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#cceeff] text-[#015a99] rounded-full mb-6">
              <Sparkles size={16} />
              <span className="text-sm">Award-Winning Creative Agency</span>
            </div>
            <h1 className="text-5xl lg:text-6xl mb-6 text-gray-900">
              Transform Your Brand with{" "}
              <span className="text-[#0177cc]">Bold</span> Advertising
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Sophilia crafts compelling campaigns that captivate audiences and
              drive results. We turn creative visions into powerful brand
              experiences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-[#0177cc] hover:bg-[#015a99]"
                onClick={scrollToContact}
              >
                Start Your Campaign
                <ArrowRight className="ml-2" size={20} />
              </Button>
              <Button size="lg" variant="outline">
                View Our Work
              </Button>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-8">
              <div>
                <div className="text-3xl text-[#0177cc] mb-2">250+</div>
                <div className="text-gray-600">Campaigns</div>
              </div>
              <div>
                <div className="text-3xl text-[#0177cc] mb-2">98%</div>
                <div className="text-gray-600">Client Satisfaction</div>
              </div>
              <div>
                <div className="text-3xl text-[#0177cc] mb-2">15+</div>
                <div className="text-gray-600">Awards Won</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1752650736352-9fa50eb3055f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGFkdmVydGlzaW5nJTIwdGVhbXxlbnwxfHx8fDE3NjA1Mjg3MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Creative advertising team"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#0177cc] rounded-full flex items-center justify-center">
                  <Sparkles className="text-white" size={24} />
                </div>
                <div>
                  <div className="text-sm text-gray-600">Creativity Score</div>
                  <div className="text-2xl text-gray-900">9.8/10</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
