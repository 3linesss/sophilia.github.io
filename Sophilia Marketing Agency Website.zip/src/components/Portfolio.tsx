import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const portfolioItems = [
  {
    title: "Tech Innovation Campaign",
    category: "Digital Marketing",
    image:
      "https://images.unsplash.com/photo-1557838923-2985c318be48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFya2V0aW5nfGVufDF8fHx8MTc2MDQ0NDM4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    result: "+245% Engagement",
  },
  {
    title: "Brand Identity Redesign",
    category: "Branding",
    image:
      "https://images.unsplash.com/photo-1759975652551-cf4cdcf52973?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGRlc2lnbiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjA0OTIzMTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    result: "Award Winner",
  },
  {
    title: "Creative Billboard Series",
    category: "Out-of-Home",
    image:
      "https://images.unsplash.com/photo-1672984581706-6c1f02cd02ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZHZlcnRpc2luZyUyMGJpbGxib2FyZHxlbnwxfHx8fDE3NjA1Mjg3MjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    result: "5M+ Impressions",
  },
  {
    title: "Social Media Revolution",
    category: "Social Strategy",
    image:
      "https://images.unsplash.com/photo-1634829862578-62786f89f2d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGNhbXBhaWdufGVufDF8fHx8MTc2MDQzMDc5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    result: "+380% Followers",
  },
];

export function Portfolio() {
  return (
    <section id="portfolio" className="py-20 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl mb-4 text-gray-900">
            Featured Work
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our portfolio of successful campaigns that have driven real
            results for our clients.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {portfolioItems.map((item, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all cursor-pointer"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <ImageWithFallback
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform">
                <Badge className="mb-3 bg-[#0177cc]">{item.category}</Badge>
                <h3 className="text-2xl mb-2">{item.title}</h3>
                <p className="text-[#5cbfff]">{item.result}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
